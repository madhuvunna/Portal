// import './App.css';
import Searchbar from './Components/Searchbar'
import EmployeeComponent from './Compo/EmployeeComponent';


function App() {
  return (
    <div className="App">

      <EmployeeComponent></EmployeeComponent>

   
    </div>
  );
}

export default App;
